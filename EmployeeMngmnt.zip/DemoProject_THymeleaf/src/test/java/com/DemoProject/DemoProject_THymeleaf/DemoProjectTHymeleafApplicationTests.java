package com.DemoProject.DemoProject_THymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProjectTHymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
