package com.DemoProject.DemoProject_THymeleaf.Controller;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.DemoProject.DemoProject_THymeleaf.Model.Employee;
import com.DemoProject.DemoProject_THymeleaf.Service.EmployeeService;

@Controller
public class EmpController {
//	@Autowired
//	private EmailService emailService;

	@Autowired
	private JavaMailSender sender;
	@Autowired
	public EmployeeService employeeService;

	@GetMapping("/")
	public String showPage(Model model) {

		model.addAttribute("listEmployees", employeeService.getallEmployees());
		return "index";
	}
	

	@GetMapping("/showNewEmployeeForm")
	public String showNewEmployee(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "new_employee";
	}

	@PostMapping("/saveEmployee")
	public String saveEmployee(@ModelAttribute("employee") Employee employee, HttpServletRequest request)
			throws MessagingException{
		employeeService.saveEmployee(employee);
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String mobNo = request.getParameter("mobNo");
		String gender = request.getParameter("gender");
		String city = request.getParameter("city");
		String married = request.getParameter("married");

		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message); 
		helper.setFrom("abathawale1995@gmail.com");
		helper.setTo("athawaleakshayb95@gmaill.com");

	//	String mailsubject = name + " sent you a message";
		String mailcontent = "<p><b>sender name:</b> " + name + "</p>";

		//mailcontent += "<p><h><b>sender mail: " + email + "</p>";
		//mailcontent += "sender name: " + name + "\n";
		mailcontent += "<p><b>sender mobile: </b> " + mobNo + "</p>";
		mailcontent += "<p><b>sender gender: </b> " + gender + "</p>";
		mailcontent += "<p><b>sender city: </b> " + city + "</p>";
		mailcontent += "<p><b>sender status: </b> " + married + "</p>";

		helper.setFrom("abathawale1995@gmail.com");
		helper.setTo(email);
		helper.setText(mailcontent, true);
	//	helper.setSubject(mailsubject);

		sender.send(message);
		System.out.println("mail sent");

//    emailService.sendEmail("athawaleakshayb95@gmail.com", "any","message" );
//	System.out.println("mail sent");

		return "redirect:/";
	}

	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") String name, Model model) {
		Employee employee = employeeService.getEmployeeById(name);
		model.addAttribute("employee", employee);
		return "update_employee";

	}

	@GetMapping("/DeleteEmployee/{id}")
	public String deleteEmployee(@PathVariable(value = "id") String name) {
		employeeService.deleteEmployeeById(name);
		return "redirect:/";
	}
}
